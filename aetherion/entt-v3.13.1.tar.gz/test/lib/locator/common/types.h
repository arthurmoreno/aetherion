#ifndef ENTT_LIB_LOCATOR_COMMON_TYPES_H
#define ENTT_LIB_LOCATOR_COMMON_TYPES_H

struct service {
    int value{};
};

#endif
