#ifndef ENTT_LIB_REGISTRY_COMMON_TYPES_H
#define ENTT_LIB_REGISTRY_COMMON_TYPES_H

struct position {
    int x{};
    int y{};
};

struct velocity {
    double dx{};
    double dy{};
};

#endif
